import java.util.Scanner;

class TugasNo1{
    
        protected double varA;
        protected double varB;
        protected double varC;

        public void setvarA(double a)
        {
            this.varA=a;
        }
        public void setvarB(double b)
        {
            this.varB=b;
        }
        public void setvarC(double c)
        {
            this.varC=c;
        }

        public double getA()
        {
            return this.varA;
        }
        public double getB()
        {
            return this.varB;
        }
        public double getC()
        {
            return this.varC;
        }
    
}
